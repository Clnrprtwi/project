<?php
class Admin extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('Model_product'); // Memuat model produk
        $this->load->model('Model_category'); // Memuat model produk
        $this->load->library('session'); // Memuat session untuk hak akses
        $this->load->helper('url'); // Memuat session untuk hak akses
        // $this->check_permissions(); // Memastikan akses hanya untuk admin/superadmin
    }

    public function index(){
       $this->check_permissions();
    }
    private function check_permissions() {
        // Contoh sederhana hak akses
        if (!$this->session->userdata('is_admin') && $this->session->userdata('logged_in')) { // Jika tidak admin, redirect
            redirect('Produk');
        }elseif(!$this->session->userdata('logged_in')){
            redirect('Login');
        }else{
            $this->load->view('admin/template/header');
            $this->load->view('admin/index');
            $this->load->view('admin/template/footer');
        }
    }

    private function do_upload() {
        $config['upload_path'] = './assets/img/product/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 2048;
        $config['max_width'] = 1024;
        $config['max_height'] = 768;

        $this->load->library('upload', $config);
        $files = $_FILES;
        $count = count($_FILES['file']['name']);
        $uploadData = array();

        for ($i = 0; $i < $count; $i++) {
            $_FILES['file']['name'] = $files['file']['name'][$i];
            $_FILES['file']['type'] = $files['file']['type'][$i];
            $_FILES['file']['tmp_name'] = $files['file']['tmp_name'][$i];
            $_FILES['file']['error'] = $files['file']['error'][$i];
            $_FILES['file']['size'] = $files['file']['size'][$i];

            // Menyesuaikan nama file yang diupload
            $new_name = time() . '_' . $i . '_' . $_FILES["file"]['name'];
            $config['file_name'] = $new_name;
            $this->upload->initialize($config);

            if ($this->upload->do_upload('file')) {
                $data = $this->upload->data();
                $uploadData[] = $data;

                // Insert file information into the database
                $fileData = array(
                    'images' => $data['file_name'],
                );
                $this->Model_product->insert_product($fileData);
            }
        }
    }

    public function account() {
        $this->load->view('admin/template/header');
            $this->load->view('admin/account');
            $this->load->view('admin/template/footer');
    }

    public function product() {
        $data['products'] = $this->Model_product->get_products(); // Mendapatkan semua produk
        $data['categories'] = $this->Model_category->get_categories();
        $this->load->view('admin/template/header');
        $this->load->view('admin/products', $data); // Tampilkan halaman admin
        $this->load->view('admin/template/footer');
    }

    public function category(){
        $data['categories'] = $this->Model_category->get_categories(); // Mendapatkan semua produk
        $this->load->view('admin/template/header');
        $this->load->view('admin/category', $data); // Tampilkan halaman admin
        $this->load->view('admin/template/footer');
    }

    public function create_product() {
        if ($_POST) { // Jika data dikirim
            $product_data = [
                'id_kategori' => $this->input->post('kategori'),
                'nm_brg' => $this->input->post('nama'),
                'hrg_brg' => $this->input->post('harga'),
                'stok_brg' => $this->input->post('stok'),
                'deskripsi_brg' => $this->input->post('deskripsi'),
            ];
            $this->do_upload();
            $this->Model_product->insert_product($product_data);
            redirect('admin/product');
        }
    }
    public function create_category() {
        if ($_POST) { // Jika data dikirim
            $input_data = [
                'jenis_brg' => $this->input->post('nama')
            ];
            $this->Model_category->insert_category($input_data);
            redirect('admin/manage_products');
        } else {
            $this->load->view('admin/template/header');
            $this->load->view('admin/create_category'); // Tampilkan form pembuatan produk
            $this->load->view('admin/template/footer');
        }
    }

    public function edit_product($id) {
        if ($_POST) { // Jika data dikirim

            $product_data = [
                'id_kategori' => $this->input->post('kategori'),
                'nm_brg' => $this->input->post('nama'),
                'hrg_brg' => $this->input->post('harga'),
                'stok_brg' => $this->input->post('stok'),
                'deskripsi_brg' => $this->input->post('deskripsi'),
            ];
            $this->Model_product->update_product($id, $product_data);
            redirect('admin/product', 'refresh');
        } else {
            $data['categories'] = $this->Model_category->get_categories();
            $data['category'] = $this->Model_category->get_category_by_id($id);
            $data['product'] = $this->Model_product->get_product_by_id($id); // Dapatkan data produk
            $this->load->view('admin/template/header');
            $this->load->view('admin/edit_product', $data); // Tampilkan form pengeditan produk
            $this->load->view('admin/template/footer');
        }
    }
    public function edit_category($id) {
        if ($_POST) { // Jika data dikirim
            $product_data = [
                'id_kategori' => $this->input->post('id'),
                'jenis_brg' => $this->input->post('nama')
            ];
            $this->Model_product->update_product($id, $product_data);
            redirect('admin/manage_category');
        } else {
            $data['categories'] = $this->Model_category->get_category_by_id($id); // Dapatkan data produk
            $this->load->view('admin/template/header');
            $this->load->view('admin/edit_category', $data); // Tampilkan form pengeditan produk
            $this->load->view('admin/template/footer');
        }
    }

    public function delete_product($id) {
        $this->Model_product->delete_product($id); // Hapus produk
        redirect('admin/product', 'refresh');
    }
    public function delete_category($id) {
        $this->Model_category->delete_category($id); // Hapus produk
        redirect('admin/category');
    }
}

?>