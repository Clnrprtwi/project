    <div class="container">
        <h1>Manajemen Produk</h1>
        <a href="<?= base_url('admin/create_product') ?>" class="btn btn-primary">Tambah Produk</a> <!-- Tombol untuk membuat produk baru -->
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Deskripsi</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?= $product->id_brg ?></td>
                        <td><?= $product->nm_brg ?></td>
                        <td><?= $product->deskripsi_brg ?></td>
                        <td><?= $product->hrg_brg ?></td>
                        <td><?= $product->stok_brg ?></td>
                        <td>
                            <a href="<?= base_url('admin/edit_product/' . $product->id_brg) ?>" class="btn btn-warning">Edit</a>
                            <a href="<?= base_url('admin/delete_product/' . $product->id_brg) ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus produk ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
