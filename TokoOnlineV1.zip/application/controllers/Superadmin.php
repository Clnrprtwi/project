<?php
// controllers/SuperAdmin.php
class SuperAdmin extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('AccessControl'); // Memuat library hak akses
        $this->AccessControl->check_superadmin(); // Memastikan hanya superadmin yang dapat mengakses
    }

    public function account() {
        // Logika untuk mengelola pengguna
        // Ini dapat mencakup daftar pengguna, mengedit pengguna, dll.
        $this->load->view('admin/account');
    }
}

?>