<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_auth extends CI_Model {

	public function check_email($email) 
	{
		if($email) {
			$sql = 'SELECT * FROM `admin` WHERE email_admin = ?';
			$query = $this->db->query($sql, array($email));
			$result = $query->num_rows();
			return ($result == 1) ? true : false;
		}

		return false;
	}

	// function Register()
	// {	
	// 	$val= array(
	// 		'nm_admin'=> htmlspecialchars($this->input->post('nama',true)), 
	// 		'Email'=> htmlspecialchars($this->input->post('email'), true) ,
	// 		'Pasword'=> password_hash($this->input->post('password'),PASSWORD_DEFAULT),
	// 		'no_tlp_admin'=> htmlspecialchars($this->input->post('nohp'),true)
	// 		// 'Alamat'=> htmlspecialchars($this->input->post('Alamat'),true)
	// 		);

	// 	$this->db->insert('admin', $val);

	// }

	// public function login($email, $password) {
	// 	if($email && $password) {
	// 		$sql = "SELECT * FROM `admin` WHERE email_admin = ?";
	// 		$query = $this->db->query($sql, array($email));

	// 		if($query->num_rows() == 1) {
	// 			$result = $query->row_array();

	// 			$hash_password = password_verify($password, $result['password']);
	// 			if($hash_password === true) {
	// 				return $result;	
	// 			}
	// 			else {
	// 				return false;
	// 			}

				
	// 		}
	// 		else {
	// 			return false;
	// 		}
	// 	}
	// }

}