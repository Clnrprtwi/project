<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" 
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" 
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <link rel="stylesheet" href="css/custome.css"> -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css')?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap-5.3.3/bootstrap.css')?>">
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="<?= base_url('assets/js/bootstrap-5.3.3/bootstrap.js')?>"></script>
    <title>Marketplace Beras</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <header>
        <div class="header-content">
            <?php if (!$this->session->userdata('logged_in')):?>
            <div class="store-name">
                <h1><i class="fas fa-user"></i><span> Guest user</span></h1>
            </div>
            <!-- <div class="search-bar">
                <input type="text" placeholder="Cari produk..." />
                <button type="button" onclick="searchProduct()">Cari</button>
            </div> -->
            <nav>
                <ul>
                    <li><a href="<?= base_url() ?>" class="nav-item"><i class="fas fa-home active"></i><span> Beranda</span></a></li>
                    <li><a href="<?= base_url('produk') ?>" class="nav-item"><i class="fa fa-truck"></i><span> Produk</span></a></li>
                    <li><a href="<?= base_url('login') ?>"><i class="fa fa-sign-in"></i> Login/Register</a></li>
                    <!-- <li><a href="#" class="nav-item"><i class="fas fa-shopping-cart"></i></a></li> -->
                </ul>
            </nav>

            <?php else: ?>
                <div class="store-name">
                <h1 style="cursor: pointer;"><i class="fas fa-user"></i><span> <?= ($this->session->userdata('nama'))?> </span></h1>
                
            </div>
            <nav>
                <ul>
                <?php if($this->session->userdata('is_admin')):?>
                    <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Dropdown</a>
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Action</a></li>
      <li><a class="dropdown-item" href="#">Another action</a></li>
      <li><a class="dropdown-item" href="#">Something else here</a></li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" href="#">Separated link</a></li>
    </ul>
  </li>
                <?php endif; ?>
                    <li><a href="<?= base_url() ?>" class="nav-item active"><i class="fas fa-home"></i><span> Beranda</span></a></li>
                    <li><a href="<?= base_url('produk') ?>" class="nav-item"><i class="fa fa-truck"></i><span> Produk</span></a></li>
                    <li><a href="<?= base_url('login/logout') ?>" class="nav-item"><i class="fa fa-sign-out"></i> Logout</a></li>
                    <li><a href="#" class="nav-item"><i class="fas fa-shopping-cart"></i></a></li>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </header>
    <!-- <nav class="bottom-nav">
    <ul>
        <li><a href="#" class="nav-item active"><i class="fas fa-home"></i><span>Beranda</span></a></li>
        <li><a href="#" class="nav-item"><i class="fas fa-search"></i><span>Cari</span></a></li>
        <li><a href="#" class="nav-item"><i class="fas fa-shopping-cart"></i><span>Keranjang</span></a></li>
        <li><a href="#" class="nav-item"><i class="fas fa-user"></i><span>Akun</span></a></li>
    </ul>
</nav> -->