<section id="products" class="products">
        <h2>Produk Beras Terbaik</h2>
        <!-- Kategori Produk -->
        <div class="category-box">
            <button class="category-button" onclick="filterCategory('all')">All Items</button>
            <button class="category-button" onclick="filterCategory('beras-putih')">Beras Putih</button>
            <button class="category-button" onclick="filterCategory('beras-merah')">Beras Merah</button>
            <button class="category-button" onclick="filterCategory('beras-hitam')">Beras Hitam</button>
        </div>

        <!-- Pencarian Produk -->
        <!--
        <div class="product-search">
            <input type="text" placeholder="Cari produk di kategori ini..." id="product-search-input" />
            <button type="button" onclick="searchInCategory()">Cari</button>
        </div> -->

        <div class="product-list">
            <div class="product-card">
                <img src="<?= base_url('assets/img/bulog.jpg')?>" alt="Produk 1" class="product-image" />
                <div class="product-details">
                    <h3 class="product-name">Beras Premium</h3>
                    <p class="product-price">Rp. 50.000,-</p>
                    <p class="product-rating">⭐⭐⭐⭐⭐</p> <!-- Rating bintang -->
                </div>
            </div>
    
            <div class="product-card">
                <img src="<?= base_url('assets/img/bulog.jpg')?>" alt="Produk 2" class="product-image" />
                <div class="product-details">
                    <h3 class="product-name">Beras Medium</h3>
                    <p class="product-price">Rp. 35.000,-</p>
                    <p class="product-rating">⭐⭐⭐⭐</p> <!-- Rating bintang -->
                </div>
            </div>
    
            <div class="product-card">
                <img src="<?= base_url('assets/img/bulog.jpg')?>" alt="Produk 3" class="product-image" />
                <div class="product-details">
                    <h3 class="product-name">Beras Organik</h3>
                    <p class="product-price">Rp. 55.000,-</p>
                    <p class="product-rating">⭐⭐⭐⭐⭐</p> <!-- Rating bintang -->
                </div>
            </div>
            <div class="product-card">
                <img src="<?= base_url('assets/img/bulog.jpg')?>" alt="Produk 3" class="product-image" />
                <div class="product-details">
                    <h3 class="product-name">Beras Organik</h3>
                    <p class="product-price">Rp. 55.000,-</p>
                    <p class="product-rating">⭐⭐⭐⭐⭐</p> <!-- Rating bintang -->
                </div>
            </div>
            <div class="product-card">
                <img src="<?= base_url('assets/img/bulog.jpg')?>" alt="Produk 3" class="product-image" />
                <div class="product-details">
                    <h3 class="product-name">Beras Organik</h3>
                    <p class="product-price">Rp. 55.000,-</p>
                    <p class="product-rating">⭐⭐⭐⭐⭐</p> <!-- Rating bintang -->
                </div>
            </div>
        </div>
    </section>