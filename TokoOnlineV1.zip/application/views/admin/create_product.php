    <div class="container">
        <h1>Tambah Produk</h1>
        <form method="POST" action="<?= base_url('admin/create_product') ?>">
            <div class="form-group">
                <label for="nama">Nama Produk</label>
                <input type="text" class="form-control" name="nama" placeholder="Masukkan Nama Produk" required>
            </div>
            <div class="form-group">
                <label for="harga">Harga</label>
                <input type="tel" class="form-control" name="harga" placeholder="Masukkan Harga" required>
            </div>
            <div class="form-group">
                <label for="kategori">Kategori</label>
                <?php foreach ($categories as $category): ?>
                <select class="form-select" name="kategori" required>
                    <option selected>Pilih Kategori</option>
                    <option value="<?= $category->id_kategori ?>"><?= $category->jenis_brg?></option>
                </select>
                <?php endforeach; ?>
            </div>
            <div class="form-group">
                <label for="stok">Stok</label>
                <input type="tel" class="form-control" name="stok" placeholder="Masukkan Stok" required>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <textarea class="form-control" name="deskripsi" placeholder="Masukkan Deskripsi"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>