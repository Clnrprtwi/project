<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['Produk'] = 'Produk/index';
$route['Produk/(:num)'] = 'produk/detail/$1';

$route['Login'] = 'Login/index';
$route['Register'] = 'Register/index';

$route['Admin'] = 'admin/index';
$route['Admin/product'] = 'admin/product';
$route['Admin/createproduct'] = 'admin/create_product';
$route['Admin/editproduct'] = 'admin/edit_product';

$route['Admin/category'] = 'admin/category';
$route['Admin/createcategory'] = 'admin/create_category';
$route['Admin/editcategory'] = 'admin/edit_category';

$route['Admin/account'] = 'admin/account';
