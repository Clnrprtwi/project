<footer>
    <p>&copy; 2024 Marketplace Beras. Hak cipta dilindungi.</p>
</footer>

<script src="<?= base_url('assets/js/scripts.js')?>"></script>
</body>
</html>