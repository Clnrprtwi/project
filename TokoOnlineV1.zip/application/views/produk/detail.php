<!-- views/produk/detail.php -->
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Detail Produk</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> <!-- Bootstrap CSS -->
</head>
<body>
    <div class="container">
        <h1>Detail Produk</h1>
        <div class="product-detail">
            <img src="<?= base_url('uploads/' . $product->image) ?>" alt="<?= $product->name ?>" class="img-fluid" /> <!-- Gambar produk -->
            <h2><?= $product->name ?></h2> <!-- Nama produk -->
            <p>Harga: Rp. <?= number_format($product->price, 0, ',', '.') ?></p> <!-- Harga produk -->
            <p><?= $product->description ?></p> <!-- Deskripsi produk -->
            <a href="<?= base_url('produk/beli/' . $product->id) ?>" class="btn btn-primary">Beli Sekarang</a> <!-- Tombol beli -->
        </div>
    </div>
</body>
