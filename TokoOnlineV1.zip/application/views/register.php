<div class="body">
        <div class="container h-100">
            <div class="row h-100 justify-content-center align-items-center">
                <div class="login-box animated" id="auth-box"> <!-- Kotak yang akan berubah -->
                    <div id="auth-content"> <!-- Konten yang dapat berubah -->
                    <h1>Daftar</h1>
                    <h3>Selamat datang, silakan isi informasi Anda</h3>
                    <?= $this->session->flashdata('message2')?>
                    <form method="POST" action="<?= base_url('Register')?>">
                        <div class="form-group">
                            <label for="nama"><i class="fas fa-user"></i> Nama *</label>
                            <input type="text" class="form-control" name="nama" placeholder="Masukkan Nama">
                        </div>
                        <div class="form-group">
                            <label for="nohp"><i class="fas fa-phone"></i> No handpone *</label>
                            <input type="tel" class="form-control" name="nohp" placeholder="Masukkan No Hp">
                        </div>
                        <div class="form-group">
                            <label for="email"><i class="fas fa-envelope"></i> Email *</label>
                            <input type="text" class="form-control" name="email" placeholder="Masukkan Email">
                        </div>
                        <div class="form-group">
                            <label for="password"><i class="fas fa-lock"></i> Password *</label>
                            <input type="password" class="form-control" name="password" placeholder="Masukkan Password">
                        </div>
                        <div class="form-group">
                            <label for="repeatpassword"><i class="fas fa-lock"></i> Repeat Password *</label>
                            <input type="password" class="form-control" name="repeatpassword" placeholder="Masukkan Password kembali">
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Daftar</button>
                        <p>Sudah punya akun? <a href="<?= base_url("Login")?>">Masuk di sini</a>.</p>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>