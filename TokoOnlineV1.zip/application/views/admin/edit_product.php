<div class="container">
    <h1>Edit Product</h1>
    <form method="POST" action="<?= base_url('admin/edit_product/' . $product->id_brg) ?>">
        <div class="form-group">
            <label for="nama">Nama Produk</label>
            <input type="text" class="form-control" name="nama" value="<?= $product->nm_brg ?>" required>
        </div>
        <div class="form-group">
            <label for="harga">Harga</label>
            <input type="text" class="form-control" name="harga" value="<?= $product->hrg_brg ?>" required>
        </div>
        <div class="form-group">
            <label for="kategori">Kategori</label>
            <select class="form-select" name="kategori" required>
            <?php foreach ($categories as $kategori): ?>
                <?php if ($kategori->id_kategori == $product->id_kategori): ?>
                    <option value="<?= $kategori->id_kategori ?>" selected><?= $kategori->jenis_brg ?></option>
                <?php endif; ?>
            <?php endforeach; ?>
            <?php foreach ($categories as $kategori): ?>
                <?php if ($kategori->id_kategori != $product->id_kategori): ?>
                    <option value="<?= $kategori->id_kategori ?>"><?= $kategori->jenis_brg ?></option>
                <?php endif; ?>
            <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="stok">Stok</label>
            <input type="tel" class="form-control" name="stok" value="<?= $product->stok_brg ?>" required>
        </div>
        <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <textarea class="form-control" name="deskripsi"><?= $product->deskripsi_brg ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>