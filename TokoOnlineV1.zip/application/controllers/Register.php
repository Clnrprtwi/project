<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Register extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		
		$this->load->model('Model_auth');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->database();
	}


	public function index(){

		$this->form_validation->set_rules('nama','nama','required|trim');
		$this->form_validation->set_rules('nohp','Number Phone','required|trim|numeric');
		// $this->form_validation->set_rules('alamat','Addres');
		$this->form_validation->set_rules('email','Email','required|trim|valid_email');
		$this->form_validation->set_rules('password','password','required|trim');
		$this->form_validation->set_rules('repeatpassword','Password','required|trim');

		if ($this->session->userdata('logged_in'))
		{
			redirect('Home');
		}
		elseif ($this->form_validation->run() == false){
			$this->load->view('template/header');
			$this->load->view('Register');
			$this->load->view('template/footer');
		}else{
				$this->_register();
		}
	}

	private function _register(){
		$Nama = $this->input->post("nama");
		$NoHp = $this->input->post("nohp");
		$email = $this->input->post("email");
		$password = $this->input->post("repeatpassword");

		// $email_exists = $this->Model_auth->check_email($email);
		// if ($email_exists == False){
			// $this->session->set_flashdata('message2', '<div class="alert alert-warning" role"alert">You Email was registered!</div> <?= $email
		// <!-- // 	redirect('Register'); -->
		// <!-- } -->
		if ($password !== $this->input->post('password')){
			$this->session->set_flashdata('message2', '<div class="alert alert-warning" role"alert">You password not same!</div> <?= $email ?>');
			redirect('Register');
		}else{
			$data = array(
				'nm_pembeli' => htmlspecialchars($Nama, true),
				'no_tlp_pembeli' => htmlspecialchars($NoHp, true),
				'email_pembeli' => htmlspecialchars($email, true),
				'password' => htmlspecialchars($password, true)
				// 'password' => password_hash($password, PASSWORD_DEFAULT)
			);
	
			$this->db->insert('pembeli', $data);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role"alert">You Succes register!</div> <?= $email ?>');
			redirect('Login', 'refresh');
		}
	}

}
