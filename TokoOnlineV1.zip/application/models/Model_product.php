<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_product extends CI_Model {
    public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->database();
	}
    public function get_products() {
        // Mendapatkan semua produk
        $query = $this->db->get('barang');
        return $query->result();
    }

    public function get_product_by_id($id) {
        // Mendapatkan produk berdasarkan ID
        $query = $this->db->get_where('barang', ['id_brg' => $id]);
        return $query->row();
    }

    public function insert_product($data) {
        // Menambahkan produk baru
        return $this->db->insert('barang', $data);
    }

    public function update_product($id, $data) {
        // Memperbarui produk berdasarkan ID
        return $this->db->update('barang', $data, ['id_brg' => $id]);
    }

    public function delete_product($id) {
        // Menghapus produk berdasarkan ID
        return $this->db->delete('barang', ['id_brg' => $id]);
    }
}
?>