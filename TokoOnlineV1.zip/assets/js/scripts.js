// scripts.js

document.addEventListener('DOMContentLoaded', function() {
    // var navItems = document.querySelectorAll('.bottom-nav .nav-item'); // Semua item di navigasi bawah

    // Menambahkan event listener untuk item navigasi
    // navItems.forEach(item => {
    //     item.addEventListener('click', function() {
    //         // Menghapus kelas 'active' dari semua item
    //         navItems.forEach(i => i.classList.remove('active'));
    //         // Menambahkan kelas 'active' pada item yang diklik
    //         this.classList.add('active');
    //     });
    // });
});
