<div class="container">
        <h1>Manajemen Kategori</h1>
        <a href="<?= base_url('admin/create_category') ?>" class="btn btn-primary">Tambah Kategori</a> <!-- Tombol untuk membuat produk baru -->
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $category): ?>
                    <tr>
                        <td><?= $category->id_kategori ?></td>
                        <td><?= $category->jenis_brg ?></td>
                        <td>
                            <a href="<?= base_url('admin/edit_category/' . $category->id_kategori) ?>" class="btn btn-warning">Edit</a>
                            <a href="<?= base_url('admin/delete_category/' . $category->id_kategori) ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus kategory ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
