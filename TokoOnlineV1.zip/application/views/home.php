
    <section id="home" class="hero animated">
        <h1>Selamat Datang di Marketplace Beras</h1>
        <p>Tempat terbaik untuk menemukan berbagai jenis beras berkualitas.</p>
        <!-- <button onclick="window.location.href='#products'">Lihat Produk</button> -->
    </section>

    <section id="about" class="about">
        <h2>Tentang Kami</h2>
        <p>Kami adalah penyedia beras berkualitas yang dipercaya di Indonesia. Kami menyediakan beras dari petani lokal dengan berbagai variasi yang dapat disesuaikan dengan kebutuhan Anda.</p>
    </section>

    <section id="contact" class="contact">
        <h2>Kontak Kami</h2>
        <p>Hubungi kami untuk pertanyaan lebih lanjut atau kerjasama.</p>
        <form>
            <input type="text" name="name" placeholder="Nama Anda" required />
            <input type="email" name="email" placeholder="Email Anda" required />
            <textarea name="message" placeholder="Pesan" required></textarea>
            <button type="submit">Kirim</button>
        </form>
    </section>