<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->database();
	}

	public function index(){

		// this for login form
		$this->form_validation->set_rules('email','email','required|trim');
		$this->form_validation->set_rules('password','password','required|trim');

		if ($this->session->userdata('logged_in'))
		{
			redirect('Home');
		}
		elseif ($this->form_validation->run() == false)
		{
			$this->load->view('template/header');
			$this->load->view('login');
			$this->load->view('template/footer');
		} else 
		{
			$this->_login();
		}
		
	}
	
	private function _login(){
		$Email = $this->input->post("email");
		$Password = $this->input->post('password');

		$Admin = $this->db->get_where('admin',['email_admin' => $Email])->row_array();
		$User = $this->db->get_where('pembeli',['email_pembeli' => $Email])->row_array();
		if($Admin){
				// cek pasword
				// if (password_verify($Password, $User['password'])) {
				if ($Password == $Admin['password']) {
					$data = [
						'email' => $Admin['email_admin'],
						'id' => $Admin['id_admin'],
						'nama' => $Admin['nm_admin'],
						'is_admin' => $Admin['is_admin'], // Misalnya, 1 jika admin
                    	'is_superadmin' => $Admin['is_superadmin'], // Misalnya, 1 jika superadmin
						'logged_in' => True
					];
						$this->session->set_userdata($data);
					if ($data['is_admin'] == True) {
						// redirect('produk_admin');
						$this->session->set_flashdata('message', '<div class="alert alert-success" role"alert">Welcome Admin! You Succes login!</div>');
						redirect('Admin/index', 'refresh');
					}
					// }elseif ($data['is_superadmin'] == True){
					// 	$this->session->set_flashdata('message', '<div class="alert alert-success" role"alert">You Succes login!</div>');
					// 	redirect('Superadmin');
				}
		}elseif($User){
			if ($Password == $User['password']) {
				$data = [
					'email' => $User['email_pembeli'],
					'id' => $User['id_pembeli'],
					'nama' => $User['nm_pembeli'],
					'logged_in' => True
				];
				$this->session->set_userdata($data);
				redirect('Produk', 'refresh');
			}else{
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role"alert">Your Password Wrong!</div> <?= $User ?>');
				redirect('Login');
			}
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role"alert">Your email wrong, Please Login Again!</div>');
			redirect('Login');
		}

	}

	

	public function logout(){
		$this->session->unset_userdata('is_admin');	
		$this->session->unset_userdata('is_superadmin');	
		$this->session->unset_userdata('email');	
		$this->session->unset_userdata('nama');
		$this->session->unset_userdata('id');
		$this->session->unset_userdata('logged_in');
		$this->session->set_flashdata('message', '<div class="alert alert-success" role"alert">You Succes logout!</div>');
		redirect('login');
	}

}
