<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Data Beras</h1>
    <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
  </div>

  <!-- Content Row -->
  <div class="row">

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Beras (Harian)</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">IDR 40,000</div>
            </div>
            <div class="col-auto">
              <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Penghasilan (Bulanan)</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">IDR 215,000</div>
            </div>
            <div class="col-auto">
              <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-info shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Stok Beras</div>
              <div class="row no-gutters align-items-center">
                <div class="col-auto">
                  <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">50%</div>
                </div>
                <div class="col">
                  <div class="progress progress-sm mr-2">
                    <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-auto">
              <i class="fas fa-truck fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Pending Requests Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-warning shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pending Payment</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
            </div>
            <div class="col-auto">
              <i class="fas fa-comments fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data Table</h6>
    </div>
    <div class="card-body">
      <button class="btn btn-primary mx-2 mb-3" data-bs-toggle="modal" data-bs-target="#create">
        Add Item
      </button>
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nama</th>
              <th>Deskripsi</th>
              <th>Harga</th>
              <th>Stok</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products as $product): ?>
              <tr>
                  <td><?= $product->id_brg ?></td>
                  <td><?= $product->nm_brg ?></td>
                  <td><?= $product->deskripsi_brg ?></td>
                  <td><?= $product->hrg_brg ?></td>
                  <td><?= $product->stok_brg ?></td>
                  <td>
                      <a href="<?= base_url('admin/edit_product/' . $product->id_brg) ?>" class="btn btn-warning">Edit</a>
                      <a href="<?= base_url('admin/delete_product/' . $product->id_brg) ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus produk ini?')">Hapus</a>
                  </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
</div>

<!-- Modal Create -->
<div class="modal fade" id="create" data-bs-backdrop="create" data-bs-keyboard="false" tabindex="-1" aria-labelledby="create" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="createLabel">Create Product</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-indicators" id="carousel-indicators"></div>
          <div class="carousel-inner" id="carousel-inner"></div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
          </button>
        </div>
        <form method="POST" action="<?= base_url('admin/create_product') ?>">
        <div class="form-group">
            <label for="image" class="form-label">Images</label>
            <input class="form-control" type="file" id="file" name="image[]" accept="image/*" multiple onchange="previewImages(event)">
        </div>
        <div class="form-group">
          <label for="nama">Nama Produk</label>
          <input type="text" class="form-control" name="nama" placeholder="Masukkan Nama Produk" required>
        </div>
        <div class="form-group">
            <label for="harga">Harga</label>
            <input type="tel" class="form-control" name="harga" placeholder="Masukkan Harga" required>
        </div>
        <div class="form-group">
            <label for="kategori">Kategori</label>
            <?php foreach ($categories as $category): ?>
            <select class="form-select" name="kategori" required>
                <option selected>Pilih Kategori</option>
                <option value="<?= $category->id_kategori ?>"><?= $category->jenis_brg?></option>
            </select>
            <?php endforeach; ?>
        </div>
        <div class="form-group">
            <label for="stok">Stok</label>
            <input type="tel" class="form-control" name="stok" placeholder="Masukkan Stok" required>
        </div>
        <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <textarea class="form-control" name="deskripsi" placeholder="Masukkan Deskripsi"></textarea>
        </div>  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Product</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- SCRIPT ONLOAD -->
<script>
  window.addEventListener('load', function () {
      $("#product").addClass('active');
  });

  function previewImages(event) {
            var files = event.target.files;
            var carouselIndicators = document.getElementById('carousel-indicators');
            var carouselInner = document.getElementById('carousel-inner');

            carouselIndicators.innerHTML = '';
            carouselInner.innerHTML = '';

            for (var i = 0; i < files.length; i++) {
                var reader = new FileReader();
                reader.onload = (function(index) {
                    return function(e) {
                        var activeClass = index === 0 ? 'active' : '';
                        var indicator = document.createElement('button');
                        indicator.setAttribute('type', 'button');
                        indicator.setAttribute('data-bs-target', '#carouselExampleIndicators');
                        indicator.setAttribute('data-bs-slide-to', index);
                        indicator.className = activeClass;

                        var controlPrev = $('.carousel-control-prev-icon');
                        controlPrev.css('background-color', 'black')

                        var controlNext = $('.carousel-control-next-icon');
                        controlNext.css('background-color', 'black')

                        var carouselItem = document.createElement('div');
                        carouselItem.className = `carousel-item ${activeClass}`;
                        var img = document.createElement('img');
                        img.src = e.target.result;
                        img.className = 'd-block w-100';

                        carouselItem.appendChild(img);
                        carouselIndicators.appendChild(indicator);
                        carouselInner.appendChild(carouselItem);
                    };
                })(i);
                reader.readAsDataURL(files[i]);
            }
        }
</script>

