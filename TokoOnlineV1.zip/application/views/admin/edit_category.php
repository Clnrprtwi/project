<div class="container">
    <h1>Edit Category</h1>
    <form method="POST" action="<?= base_url('admin/edit_category/' . $product->id_brg) ?>">
        <div class="form-group">
            <label for="name">Nama Produk</label>
            <input type="text" class="form-control" name="name" value="<?= $product->nm_brg ?>" required>
        </div>
        <div class="form-group">
            <label for="price">Harga</label>
            <input type="text" class="form-control" name="price" value="<?= $product->hrg_brg ?>" required>
        </div>
        <div class="form-group">
            <label for="kategori">Kategori</label>
            <?php foreach ($categories as $category): ?>
            <select class="form-select" name="kategori" required>
                <option selected>Pilih Kategori</option>
                <option value="<?= $category->id_kategori ?>"><?= $category->jenis_brg?></option>
            </select>
            <?php endforeach; ?>
        </div>
        <div class="form-group">
            <label for="stok">Stok</label>
            <input type="tel" class="form-control" name="stok" value="<?= $product->stok_brg ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Deskripsi</label>
            <textarea class="form-control" name="description"><?= $product->deskripsi_brg ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>