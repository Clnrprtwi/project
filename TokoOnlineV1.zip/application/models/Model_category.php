<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_category extends CI_Model {
    public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->database();
	}

    public function get_categories() {
        // Mendapatkan semua produk
        $query = $this->db->get('kategori');
        return $query->result();
    }

    public function get_category_by_id($id) {
        // Mendapatkan produk berdasarkan ID
        $query = $this->db->get_where('kategori', ['id_kategori' => $id]);
        return $query->result();
    }

    public function insert_category($data) {
        // Menambahkan produk baru
        return $this->db->insert('kategori', $data);
    }

    public function update_category($id, $data) {
        // Memperbarui produk berdasarkan ID
        return $this->db->update('kategori', $data, ['id_kategori' => $id]);
    }

    public function delete_category($id) {
        // Menghapus produk berdasarkan ID
        return $this->db->delete('kategori', ['id_kategori' => $id]);
    }
}
?>