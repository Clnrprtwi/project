<div class="container">
        <h1>Tambah Kategory</h1>
        <form method="POST" action="<?= base_url('admin/create_category') ?>">
            <div class="form-group">
                <label for="nama">Nama Category</label>
                <input type="text" class="form-control" name="nama" placeholder="Masukkan Nama Kategori" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>