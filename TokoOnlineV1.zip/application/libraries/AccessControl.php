<?php
// libraries/AccessControl.php
class AccessControl {
    public function check_superadmin() {
        // Logika sederhana untuk memastikan hanya superadmin yang dapat mengakses
        $CI = &get_instance();
        if (!$CI->session->userdata('is_superadmin')) { // Jika bukan superadmin, redirect
            redirect('Login');
        }
    }
}
?>