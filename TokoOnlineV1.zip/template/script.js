// scripts.js

document.addEventListener('DOMContentLoaded', function() {
    var registerLink = document.getElementById('register-link'); // Tautan untuk daftar
    var authContent = document.getElementById('auth-content'); // Konten yang dapat diubah

    registerLink.addEventListener('click', function(e) {
        e.preventDefault(); // Mencegah perilaku default

        // Mengganti konten dengan transisi halus
        authContent.classList.add('hidden'); // Menambahkan kelas untuk memulai transisi keluar

        setTimeout(() => {
            authContent.innerHTML = `
                <h1>Daftar</h1>
                <h3>Selamat datang, silakan isi informasi Anda</h3>
                <form method="POST" action="register">
                    <div class="form-group">
                        <label for="name"><i class="fas fa-user"></i> Nama</label>
                        <input type="text" class="form-control" name="name" placeholder="Masukkan Nama">
                    </div>
                    <div class="form-group">
                        <label for="email"><i class="fas fa-envelope"></i> Email</label>
                        <input type="text" class="form-control" name="email" placeholder="Masukkan Email">
                    </div>
                    <div class="form-group">
                        <label for="password"><i class="fas fa-lock"></i> Password</label>
                        <input type="password" class="form-control" name="password" placeholder="Masukkan Password">
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Daftar</button>
                    <p>Sudah punya akun? <a href="#" id="login-link">Masuk di sini</a>.</p>
                </form>
            `;

            // Menghapus kelas hidden setelah perubahan konten
            authContent.classList.remove('hidden'); // Transisi masuk

            // Tambahkan event listener untuk tautan login
            var loginLink = document.getElementById('login-link');
            loginLink.addEventListener('click', function(e) {
                e.preventDefault();
                // Kembalikan konten ke formulir login
                authContent.classList.add('hidden'); // Transisi keluar
                setTimeout(() => {
                    authContent.innerHTML = `
                        <h1>Login</h1>
                        <h3>Semoga harimu menyenangkan</h3>
                        <form method="POST" action="login">
                            <div class="form-group">
                                <label for="email"><i class="fas fa-user"></i> Email</label>
                                <input type="text" class="form-control" name="email" placeholder="Masukkan Email">
                            </div>
                            <div class="form-group">
                                <label for="password"><i fas fa-lock"></i> Password</label>
                                <input type="password" class="form-control" name="password" placeholder="Masukkan Password">
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                            <p>Tidak punya akun? <a href="#" id="register-link">Daftar di sini</a>.</p>
                        </form>
                    `;
                    authContent.classList.remove('hidden'); // Transisi masuk lagi
                }, 500); // Waktu transisi yang sama
            });
        }, 500); // Waktu transisi sebelum perubahan konten
    });
});
