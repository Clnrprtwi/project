<?php

class Produk extends CI_Controller {

    public function __construct(){
		parent::__construct();
		// $this->load->library('form_validation');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->model('Model_product');

	}

	public function index(){

		$this->load->view('template/header');
		$this->load->view('produk/index');
		$this->load->view('template/footer');
	}

	public function detail($id_brg) { // Menerima ID produk dari URL
        $data['product'] = $this->Model_product->get_product_by_id($id_brg); // Mendapatkan data produk
        if ($data['product']) { // Jika produk ditemukan
            $this->load->view('produk/detail', $data); // Muat tampilan detail
        } else {
            show_404(); // Jika produk tidak ditemukan, tampilkan 404
        }
    }
}
